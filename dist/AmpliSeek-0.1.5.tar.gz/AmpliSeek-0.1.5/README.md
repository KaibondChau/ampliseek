# AmpliSeek


### Installation
Conda + pip
- conda create -n ampliseek -c bioconda python=3 bbmap biopython
- conda activate ampliseek
- pip install ampliseek